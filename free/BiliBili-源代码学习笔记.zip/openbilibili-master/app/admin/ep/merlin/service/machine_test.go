package service

import (
	"testing"

	. "github.com/smartystreets/goconvey/convey"
)

func TestGenMachines(t *testing.T) {
	Convey("test UserTree", t, func() {
		//TODO
	})
}
