# HERO

## 人类（Human）

- 大法师（Arch mage）-- AM
- 山丘之王（Mountain King）-- MK
- 圣骑士（Paladin）-- PAL
- 血法师（Blood Mage）-- BMG

## 兽族（Orc）

- 先知（Far Seer）-- FS
- 暗影猎手（Shadow hunter）-- XY
- 牛头人酋长（Tauren Chieftain）-- NT
- 剑圣（BladeMaster）-- BM

## 暗夜（Night Elf）

- 守望者（Warden）-- WD
- 月之女祭师（Priess Of the moon）-- POM
- 恶魔猎手（Demon Hunter）-- DH
- 丛林守护者（Keepper of the grove）-- KOG

## 亡灵（Undead）

- 地穴领主（Crypt Lord）-- CL
- 死亡骑士（Death Knight）-- DK
- 巫妖（Lich）-- LICH
- 恐惧魔王（Dread Lord）-- DL

## 中立

- 熊猫酒仙（Pandarenbrewer）-- XM
- 火焰领主（Flame Lord）-- FL
- 地精炼金术士（Goblin Alchemist）-- LJ
- 深渊魔王（Pit Lord）-- PL
- 黑暗游侠（Dark Ranger）-- BR
- 驯兽师（BEASTMASTER）-- SW
- 地精修补匠（Tinker）-- TINKER
- 娜迦女海巫（Naga Seawitch）-- Naga
