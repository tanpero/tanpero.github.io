# go-common/business

业务仓库目录

| 目录 | 描述 |
| -------- | -------------- |
| service  | rpc service    |
| client   | rpc client sdk |
| interface| gateway        |
| admin    | 运营管理服务   |
| job      | 后台异步服务job|
| model    | 业务实体model  |
| ecode    | 统一错误码     |
